# -*- coding: utf-8 -*-
"""
Пакет приложения CallAnnotate

Автор: akoodoy@capilot.ru
Ссылка: https://github.com/momentics/CallAnnotate
Лицензия: Apache-2.0
"""
